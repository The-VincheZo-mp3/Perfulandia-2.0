package com.example.Perfulandia.controller;

public class SucursalController {

}

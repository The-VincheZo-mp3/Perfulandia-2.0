package com.perfulandia.test;

import com.perfulandia.service.ProductoService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ProductoServiceTest {

    @Test
    void testProductoServiceNotNull() {
        ProductoService productoService = Mockito.mock(ProductoService.class);
        assertNotNull(productoService);
    }
}
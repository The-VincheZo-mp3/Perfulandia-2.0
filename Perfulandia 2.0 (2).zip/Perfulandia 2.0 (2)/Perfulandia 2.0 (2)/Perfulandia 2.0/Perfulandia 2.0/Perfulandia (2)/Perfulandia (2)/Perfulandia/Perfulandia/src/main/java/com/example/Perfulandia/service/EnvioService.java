package com.example.Perfulandia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

import com.example.Perfulandia.model.modelEnvio;
import com.example.Perfulandia.repository.EnvioRepository;

@Service
public class EnvioService {

    @Autowired
    private EnvioRepository envioRepository;

    public List<modelEnvio> listar() {
        return envioRepository.findAll();
    }

    public modelEnvio guardar(modelEnvio envio) {
        return envioRepository.save(envio);
    }

    public void eliminar(Long id) {
        envioRepository.deleteById(id);
    }

    public Optional<modelEnvio> buscarPorId(Long id) {
        return envioRepository.findById(id);
    }
}

package com.example.Perfulandia.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Perfulandia.model.ModelVenta;

public interface VentaRepository extends JpaRepository<ModelVenta, Long> {
}
package com.example.Perfulandia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.example.Perfulandia.model.ModelUsuario;
import com.example.Perfulandia.repository.UsuarioRepository;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public List<ModelUsuario> listar() {
        return usuarioRepository.findAll();
    }

    public ModelUsuario guardar(ModelUsuario u) {
        return usuarioRepository.save(u);
    }

    public void eliminar(Long id) {
        usuarioRepository.deleteById(id);
    }

    public Optional<ModelUsuario> buscarPorId(Long id) {
        return usuarioRepository.findById(id);
    }
}

package com.example.Perfulandia.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.example.Perfulandia.model.ModelSucursal;
import com.example.Perfulandia.service.SucursalService;

@RestController
@RequestMapping("/api/sucursales")
public class SucursalController {

    private final SucursalService sucursalService;

    public SucursalController(SucursalService sucursalService) {
        this.sucursalService = sucursalService;
    }

    @GetMapping
    public List<ModelSucursal> getAllSucursales() {
        return sucursalService.listar();
    }

    @PostMapping
    public ModelSucursal createSucursal(@RequestBody ModelSucursal sucursal) {
        return sucursalService.guardar(sucursal);
    }

    @PutMapping("/{id}")
    public ModelSucursal updateSucursal(@PathVariable Long id, @RequestBody ModelSucursal sucursal) {
        sucursal.setId(id);
        return sucursalService.guardar(sucursal);
    }

    @DeleteMapping("/{id}")
    public void deleteSucursal(@PathVariable Long id) {
        sucursalService.eliminar(id);
    }
}
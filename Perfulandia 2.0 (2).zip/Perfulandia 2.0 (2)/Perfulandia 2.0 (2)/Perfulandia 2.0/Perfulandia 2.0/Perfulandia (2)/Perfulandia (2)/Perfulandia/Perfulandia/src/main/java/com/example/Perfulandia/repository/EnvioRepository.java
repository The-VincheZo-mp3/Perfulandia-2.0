package com.example.Perfulandia.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Perfulandia.model.modelEnvio;

public interface EnvioRepository extends JpaRepository<modelEnvio, Long> {
}
package com.example.Perfulandia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.example.Perfulandia.model.ModelSucursal;
import com.example.Perfulandia.repository.SucursalRepository;

@Service
public class SucursalService {

    @Autowired
    private SucursalRepository sucursalRepository;

    public List<ModelSucursal> listar() {
        return sucursalRepository.findAll();
    }

    public ModelSucursal guardar(ModelSucursal s) {
        return sucursalRepository.save(s);
    }

    public void eliminar(Long id) {
        sucursalRepository.deleteById(id);
    }

    public Optional<ModelSucursal> buscarPorId(Long id) {
        return sucursalRepository.findById(id);
    }
}

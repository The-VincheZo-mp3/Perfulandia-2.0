package com.example.Perfulandia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import com.example.Perfulandia.model.ModelVenta;
import com.example.Perfulandia.repository.VentaRepository;

@Service
public class VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    public List<ModelVenta> listar() {
        return ventaRepository.findAll();
    }

    public ModelVenta guardar(ModelVenta v) {
        return ventaRepository.save(v);
    }

    public void eliminar(Long id) {
        ventaRepository.deleteById(id);
    }

    public Optional<ModelVenta> buscarPorId(Long id) {
        return ventaRepository.findById(id);
    }
}

package com.example.Perfulandia.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.example.Perfulandia.model.ModelVenta;
import com.example.Perfulandia.service.VentaService;

@RestController
@RequestMapping("/api/ventas")
public class VentaController {

    private final VentaService ventaService;

    public VentaController(VentaService ventaService) {
        this.ventaService = ventaService;
    }

    @GetMapping
    public List<ModelVenta> getAllVentas() {
        return ventaService.listar();
    }

    @PostMapping
    public ModelVenta createVenta(@RequestBody ModelVenta venta) {
        return ventaService.guardar(venta);
    }

    @PutMapping("/{id}")
    public ModelVenta updateVenta(@PathVariable Long id, @RequestBody ModelVenta venta) {
        venta.setId(id);
        return ventaService.guardar(venta);
    }

    @DeleteMapping("/{id}")
    public void deleteVenta(@PathVariable Long id) {
        ventaService.eliminar(id);
    }
}

package com.example.Perfulandia.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.example.Perfulandia.model.ModelUsuario;
import com.example.Perfulandia.service.UsuarioService;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping
    public List<ModelUsuario> getAllUsuarios() {
        return usuarioService.listar();
    }

    @PostMapping
    public ModelUsuario createUsuario(@RequestBody ModelUsuario usuario) {
        return usuarioService.guardar(usuario);
    }

    @PutMapping("/{id}")
    public ModelUsuario updateUsuario(@PathVariable Long id, @RequestBody ModelUsuario usuario) {
        usuario.setId(id);
        return usuarioService.guardar(usuario);
    }

    @DeleteMapping("/{id}")
    public void deleteUsuario(@PathVariable Long id) {
        usuarioService.eliminar(id);
    }
}
package com.example.Perfulandia.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.example.Perfulandia.model.modelEnvio;
import com.example.Perfulandia.service.EnvioService;

@RestController
@RequestMapping("/api/envios")
public class EnvioController {

    private final EnvioService envioService;

    public EnvioController(EnvioService envioService) {
        this.envioService = envioService;
    }

    @GetMapping
    public List<modelEnvio> getAllEnvios() {
        return envioService.listar();
    }

    @PostMapping
    public modelEnvio createEnvio(@RequestBody modelEnvio envio) {
        return envioService.guardar(envio);
    }

    @PutMapping("/{id}")
    public modelEnvio updateEnvio(@PathVariable Long id, @RequestBody modelEnvio envio) {
        envio.setId(id); // Asegúrate de que modelEnvio tenga el método setId
        return envioService.guardar(envio);
    }

    @DeleteMapping("/{id}")
    public void deleteEnvio(@PathVariable Long id) {
        envioService.eliminar(id);
    }
}